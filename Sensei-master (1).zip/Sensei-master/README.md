# Sensei
Dark-Fb No Login 100% safe
<img src="https://github.com/BOT-033/Sensei/blob/master/Screenshot_2020-07-16-00-13-54-17.jpg">
# Module
```
• pip2 install tqdm
• pip2 install requests
• pip2 install mechanize
```
# Install
```
• git clone https://github.com/BOT-033/Sensei
• cd Sensei
• python2 main.py
```
